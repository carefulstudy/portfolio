===============================
      *** README ***
  Copyright: Robin Wåge 2024 
===============================
          .-------.
       .-´(_______)`-.
    .-´               `-.
   (                     )
    `.                 .´
      `-.___________.-´
        /  ( ) ( )  \
       /   ( ) ( )   \
===============================
   ** WAVE FORM DETECTED **

HOW TO Enable Auto-Signin (Does not work in the demo version!)
1. Open the "config.ini" file in the config/ folder.
2. Set `enable_hashed_credentials` to `"1"`.
3. a. A "hash_credentials" file will be generated.
   b. This file gives access to your account. Keep it safe and private.

HOW-TO Enable Error Capture
1. Open the "config.ini" file in the config/ folder.
2. Set `generate_trace_file` to `"1"`.
3. a. A "App_Fault.log" file will be generated.
   b. Send it to: mail@psifreak.com

===============================
  *** END OF TRANSMISSION ***
===============================
